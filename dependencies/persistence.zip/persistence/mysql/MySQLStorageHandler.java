package atom.persistence.mysql;

import atom.http_server.model.profiling.*;
import atom.persistence.base.AbstractStorageHandler;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.jdbc.JdbcConnectionSource;
import com.j256.ormlite.table.TableUtils;

import java.sql.SQLException;

/**
 * Created by sergio on 16/2/16.
 */
public class MySQLStorageHandler extends AbstractStorageHandler {

    private static final String MYSQL_URL = "jdbc:mysql://localhost:3306/atom?user=root&pass=root";
    private JdbcConnectionSource connectionSource;
    private boolean connected;

    public MySQLStorageHandler(String name) {
        super();
        this.name = name;
    }

    @Override
    public boolean close() {
        // close the connection source
        try {
            connectionSource.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean isConnected() {
        return connectionSource != null && connectionSource.isOpen();
    }

    @Override
    public boolean connect(String ip) {
        try {
            connectionSource = new JdbcConnectionSource(MYSQL_URL);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean connect(String... ip) {
        return false;
    }

    @Override
    public boolean executeQuery(String query) {
        return false;
    }

    @Override
    public void saveUserProfile(UserProfile userProfile) {
        checkConnection();
        // instantiate the dao
        try {
            Dao<UserProfile, String> userProfileDAO = DaoManager.createDao(connectionSource, UserProfile.class);
            if (!existsAlready(userProfileDAO, userProfile))
                userProfileDAO.createOrUpdate(userProfile);

            //save cpus info
            Dao<CpusInfo, String> cpuDAO = DaoManager.createDao(connectionSource, CpusInfo.class);

            for (CpusInfo c : userProfile.getCpusInfo()) {
                c.setOwner(userProfile);
                cpuDAO.createOrUpdate(c);
            }

            //save network cards info
            Dao<NetworkCard, String> cardDAO = DaoManager.createDao(connectionSource, NetworkCard.class);
            for (NetworkCard c : userProfile.getNetworkInterfaces().getEn0()) {
                c.setOwner(userProfile.getNetworkInterfaces());
                cardDAO.createOrUpdate(c);
            }
            for (NetworkCard c : userProfile.getNetworkInterfaces().getLo0()) {
                c.setOwner(userProfile.getNetworkInterfaces());
                cardDAO.createOrUpdate(c);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean createModel() {
        checkConnection();
        try {
            TableUtils.createTable(connectionSource, Vars.class);
            TableUtils.createTable(connectionSource, NetworkCard.class);
            TableUtils.createTable(connectionSource, CpusInfo.class);
            TableUtils.createTable(connectionSource, NetworkInterfaces.class);
            TableUtils.createTable(connectionSource, UserProfile.class);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void checkConnection() {
        if (!isConnected()) {
            connect(MYSQL_URL);
        }
    }

    private boolean existsAlready(Dao dao, Object object) {
        try {
            return dao.queryForSameId(object) != null;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
