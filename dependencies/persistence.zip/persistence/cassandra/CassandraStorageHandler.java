package atom.persistence.cassandra;

import atom.http_server.model.profiling.UserProfile;
import atom.persistence.base.AbstractStorageHandler;
import atom.persistence.base.PersistenceType;
import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Host;
import com.datastax.driver.core.Metadata;
import com.datastax.driver.core.Session;

/**
 * Created by sergio on 16/2/16.
 */

public class CassandraStorageHandler extends AbstractStorageHandler {

    private Cluster cluster;
    private Session session;

    private String keySpaceName;

    public CassandraStorageHandler() {
        super();
        this.name = PersistenceType.CASSANDRA.getName();
    }

    public CassandraStorageHandler(String name) {
        super();
        this.name = name;
    }

    @Override
    public boolean close() {
        if (cluster != null)
            cluster.close();
        if (session != null)
            session.close();
        return true;
    }

    @Override
    public boolean isConnected() {
        return session != null && !session.isClosed();
    }

    @Override
    public boolean connect(String node) {
        cluster = Cluster.builder()
                .addContactPoint(node).build();
        Metadata metadata = cluster.getMetadata();
        System.out.printf("Connected to cluster: %s\n", metadata.getClusterName());
        for (Host host : metadata.getAllHosts()) {
            System.out.printf("Datatacenter: %s; Host: %s; Rack: %s\n", host.getDatacenter(), host.getAddress(), host.getRack());
        }
        connectToKeyspace();
        return true;
    }

    @Override
    public boolean connect(String[] nodes) {
        cluster = Cluster.builder()
                .addContactPoints(nodes).build();
        Metadata metadata = cluster.getMetadata();
        System.out.printf("Connected to cluster: %s\n", metadata.getClusterName());
        for (Host host : metadata.getAllHosts()) {
            System.out.printf("Datatacenter: %s; Host: %s; Rack: %s\n", host.getDatacenter(), host.getAddress(), host.getRack());
        }
        connectToKeyspace();
        return true;
    }

    @Override
    public boolean executeQuery(String query) {
        return false;
    }

    public Session getSession() {
        return this.session;
    }

    private void connectToKeyspace() {
        if (keySpaceName == null)
            throw new NullPointerException("Keyspace of the current Cassandra storage handler is NULL");
        session = cluster.connect(keySpaceName);
    }

    public String getKeySpaceName() {
        return keySpaceName;
    }

    public void setKeySpaceName(String keySpaceName) {
        this.keySpaceName = keySpaceName;
    }

    @Override
    public void saveUserProfile(UserProfile userProfile) {

    }

    @Override
    public boolean createModel() {
        return false;
    }
}
