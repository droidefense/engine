package atom.persistence;

import atom.persistence.base.PersistenceManager;

import java.sql.SQLException;

/**
 * Created by sergio on 24/4/16.
 */
public class Demo {

    public static void main(String[] args) throws SQLException {

        PersistenceManager manager = PersistenceManager.getInstance();
        manager.createModel();
        manager.close();
    }
}
