package atom.persistence.base;

import atom.persistence.cassandra.CassandraStorageHandler;
import atom.persistence.mysql.MySQLStorageHandler;

/**
 * Created by sergio on 21/2/16.
 */
public enum PersistenceType {

    MYSQL {
        @Override
        public AbstractStorageHandler getBuilder() {
            return new MySQLStorageHandler(getName());
        }

        @Override
        public String getName() {
            return "MySQL";
        }
    }, CASSANDRA {
        @Override
        public AbstractStorageHandler getBuilder() {
            return new CassandraStorageHandler(getName());
        }

        @Override
        public String getName() {
            return "Apache Cassandra";
        }
    };

    public abstract AbstractStorageHandler getBuilder();

    public abstract String getName();
}
