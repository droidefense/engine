package atom.persistence.base;

import atom.http_server.model.profiling.UserProfile;

/**
 * Created by sergio on 24/4/16.
 */
public interface IStorageManager {
    void saveUserProfile(UserProfile userProfile);

    boolean createModel();

    boolean close();

    boolean isConnected();
}
