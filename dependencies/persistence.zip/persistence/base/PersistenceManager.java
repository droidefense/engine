package atom.persistence.base;

import atom.http_server.model.profiling.UserProfile;

/**
 * Created by sergio on 21/2/16.
 */
public class PersistenceManager implements IStorageManager {

    private static PersistenceManager instance;
    private static AbstractStorageHandler currentHandler;
    private static PersistenceType type = PersistenceType.MYSQL;

    private PersistenceManager(PersistenceType type) {
        if (currentHandler == null)
            currentHandler = type.getBuilder();
        if (!type.name().equalsIgnoreCase(currentHandler.getName()))
            throw new RuntimeException("You are requesting a data storage using " + type.name() + ", but you have previously selected to use " + currentHandler.getName());
    }

    public static void main(String[] args) {

        PersistenceManager manager = PersistenceManager.getInstance();
        manager.saveUserProfile(new UserProfile());
    }

    public static PersistenceManager getInstance() {
        if (instance == null)
            instance = new PersistenceManager(type);
        return instance;
    }


    @Override
    public void saveUserProfile(UserProfile userProfile) {
        currentHandler.saveUserProfile(userProfile);
    }

    @Override
    public boolean createModel() {
        return currentHandler.createModel();
    }

    @Override
    public boolean close() {
        return currentHandler.close();
    }

    @Override
    public boolean isConnected() {
        return currentHandler.isConnected();
    }
}
