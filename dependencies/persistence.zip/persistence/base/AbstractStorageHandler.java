package atom.persistence.base;

/**
 * Created by sanguita on 12/02/2016.
 */
public abstract class AbstractStorageHandler implements IStorageManager {

    protected static AbstractStorageHandler instance;
    protected String name;

    public abstract boolean close();

    public abstract boolean connect(String ip);

    public abstract boolean connect(String... ip);

    public abstract boolean executeQuery(String query);

    public String getName() {
        return name;
    }
}
