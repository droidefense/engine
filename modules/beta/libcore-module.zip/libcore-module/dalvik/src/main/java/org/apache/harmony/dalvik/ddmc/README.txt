These classes are tied to the VM, e.g. the VM may invoke some of the methods.
